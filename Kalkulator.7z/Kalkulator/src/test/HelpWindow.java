package test;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Font;
import java.awt.Canvas;
import javax.swing.JScrollPane;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;

/**
 * Informacje o autorze:
 * 
 * @author Wojciech Nowak
 * @version 1.1
 */

public class HelpWindow extends JDialog {
	
	private static final long serialVersionUID = 1L;
	private static final int WIDTH = 150;
	private static final int HEIGHT = 100;
	
	public HelpWindow () {
		
		setTitle("Pomoc");
		setResizable(false);
		
		// Przycisk OK zamyka okno
		JButton ok = new JButton("OK");
		ok.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		
		// Dodanie przycisku OK przy krawedzi dolnej
		JPanel panel = new JPanel();
		panel.add(ok);
		getContentPane().add(panel, BorderLayout.SOUTH);
		
		JPanel panel_1 = new JPanel();
		getContentPane().add(panel_1, BorderLayout.CENTER);
		panel_1.setLayout(null);
		
		JLabel lblProgramGui = new JLabel("Kalkulator - Instrukcja");
		lblProgramGui.setHorizontalAlignment(SwingConstants.CENTER);
		lblProgramGui.setFont(new Font("SansSerif", Font.BOLD, 24));
		lblProgramGui.setBounds(96, 11, 300, 40);
		panel_1.add(lblProgramGui);
		
		JLabel lblFunkcjeProgarmu = new JLabel("Opis funkcji programu");
		lblFunkcjeProgarmu.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblFunkcjeProgarmu.setBounds(18, 50, 226, 29);
		panel_1.add(lblFunkcjeProgarmu);
		
		JLabel lblNewLabel = new JLabel("Dodawanie : Wybierz 1 liczb\u0119, wybierz znak dodawania, wybierz 2 liczb\u0119, wybierz =");
		lblNewLabel.setVerticalAlignment(SwingConstants.TOP);
		lblNewLabel.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel.setBounds(50, 112, 739, 14);
		panel_1.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Odejmowanie : Wybierz 1 liczb\u0119, wybierz znak odejmowania, wybierz 2 liczb\u0119, wybierz =");
		lblNewLabel_1.setBounds(50, 137, 663, 14);
		panel_1.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Mno\u017Cenie : Wybierz 1 liczb\u0119, wybierz znak mno\u017Cenia, wybierz 2 liczb\u0119, wybierz =");
		lblNewLabel_2.setBounds(50, 162, 605, 14);
		panel_1.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Dzielenie : Wybierz 1 liczb\u0119, wybierz znak dzielenia, wybierz 2 liczb\u0119, wybierz =");
		lblNewLabel_3.setBounds(50, 187, 605, 14);
		panel_1.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Pierwiastkowanie : Wybierz 1 liczb\u0119, wybierz znak pierwiastkowania, wybierz 2 liczb\u0119 ( stopie\u0144 pierwiastka), wybierz =");
		lblNewLabel_4.setBounds(50, 212, 701, 14);
		panel_1.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Pot\u0119gowanie: Wybierz 1 liczb\u0119, wybierz znak pot\u0119gowania, wybierz 2 liczb\u0119(pot\u0119ga 1 liczby), wybierz =");
		lblNewLabel_5.setBounds(50, 237, 663, 14);
		panel_1.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("Procent : Wybierz 1 liczb\u0119, wybierz znak procentu, wybierz 2 liczb\u0119, wybierz =, wynik to procent 1 liczby z 2 ");
		lblNewLabel_6.setBounds(50, 262, 663, 14);
		panel_1.add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("W razie problem\u00F3w przeczytaj intrukcj\u0119 u\u017Cytkownika ");
		lblNewLabel_7.setBounds(50, 301, 461, 14);
		panel_1.add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("Autorzy : Zesp\u00F3\u0142 projektowy pod wezwaniem Dr. Marka Pop\u0142awskiego :D");
		lblNewLabel_8.setBounds(375, 59, 445, 14);
		panel_1.add(lblNewLabel_8);
		
		JLabel lblNewLabel_9 = new JLabel("Wersja programu : 1.0.1");
		lblNewLabel_9.setBounds(611, 312, 140, 14);
		panel_1.add(lblNewLabel_9);
		
		JLabel lblCopyrightc = new JLabel("Copyright (C) - 2020");
		lblCopyrightc.setBounds(621, 337, 111, 14);
		panel_1.add(lblCopyrightc);
		Dimension frameSize = new Dimension(WIDTH,HEIGHT);			
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize(); //pobranie rozdzielczosci pulpitu 
		if(frameSize.height > screenSize.height) frameSize.height = screenSize.height;
		if(frameSize.width > screenSize.width) frameSize.width = screenSize.width;
		setSize(new Dimension(836, 432));	
		
		// Rozmieszczenie okna na srodku aplikacji
		setLocation((screenSize.width-frameSize.width)/2, 
					(screenSize.height-frameSize.height)/2);
	}
}
