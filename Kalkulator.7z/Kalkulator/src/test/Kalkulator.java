package test;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Rectangle2D;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.util.Date;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JMenu;
import javax.swing.JSeparator;
import javax.swing.JToolBar;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JSpinner;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

import javax.swing.JTextArea;
import javax.swing.JComboBox;
import javax.swing.AbstractAction;
import javax.swing.AbstractButton;
import javax.swing.DefaultComboBoxModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JPanel;
import javax.swing.JList;
import java.awt.Color;
import javax.swing.UIManager;
import javax.swing.ListSelectionModel;
import javax.swing.ScrollPaneConstants;
import java.awt.FlowLayout;

import java.awt.EventQueue;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Panel;
import javax.swing.JRadioButton;
/**
* @author Wojciech Nowak
*/
public class Kalkulator extends JFrame implements ActionListener {



	private JPanel PanelCenter;
    private String[] yesNo = {"Tak", "Nie"};
    private JTextField resultArea;
    private JButton btn1;
    private JButton btn2;
    private JButton btn3;
    private JButton btn4;
    private JButton btn5;
    private JButton btn6;
    private JButton btn7;
    private JButton btn8;
    private JButton btn9;
    private JButton btn0;
    private JButton btnDodawanie;
    private JButton btnOdejmowanie;
    private JButton btnMnozenie;
    private JButton btnDzielenie;
    private JButton btnwynik;
    private JButton btnClear;
    private JButton btnprocent;
    private JButton btnpotega;
    private JButton btnpierwiastek;
    private double TEMP;
    private double SolveTEMP;
   
    private HelpWindow help;
    private Panel panel;
    
    private Boolean addBool = false;
    private Boolean subBool = false;
    private Boolean divBool = false;
    private Boolean mulBool = false;
    private Boolean sqrtBool = false;
    private Boolean dobBool = false;
    private Boolean percentBool = false;
    
    private String display = " ";
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Kalkulator frame = new Kalkulator();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Kalkulator() {
		setTitle("Kalkulator prosty");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 487, 410);
		PanelCenter = new JPanel();
		PanelCenter.setForeground(Color.BLACK);
		PanelCenter.setBackground(Color.DARK_GRAY);
		PanelCenter.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(PanelCenter);
		this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                windowClose();
            }
        });
		
		
        
        
        
        /** PANEL  */
        PanelCenter.setLayout(null);
        
        resultArea = new JTextField();
        resultArea.setForeground(Color.BLACK);
        resultArea.setEditable(false);
        resultArea.setBounds(10, 11, 453, 154);
        PanelCenter.add(resultArea);
        resultArea.setColumns(10);

        
        
        Panel panel = new Panel();
        panel.setBounds(0, 171, 463, 183);
        PanelCenter.add(panel);
        panel.setLayout(null);
        
        
        /** Sekcja MENU - pocz�tek */

        JMenuBar menuBar = new JMenuBar();
        menuBar.setBackground(Color.DARK_GRAY);
        setJMenuBar(menuBar);

        JMenu menuFile = new JMenu("Plik");
        menuFile.setForeground(new Color(255, 215, 0));
        menuBar.add(menuFile);

        JMenuItem itemExit = new JMenuItem("Wyj�cie");
        itemExit.setBackground(Color.DARK_GRAY);
        itemExit.setForeground(new Color(255, 215, 0));
        menuFile.add(itemExit);
        itemExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                windowClose();
            }
        });
        
        
        /**   */
        
        JMenu menuInfo = new JMenu("Informacje");
        menuInfo.setForeground(new Color(255, 215, 0));
        menuBar.add(menuInfo);
        
        JMenuItem itemInfo = new JMenuItem("Pomoc");
        itemInfo.setForeground(new Color(255, 215, 0));
        itemInfo.setBackground(Color.DARK_GRAY);
        menuInfo.add(itemInfo);
        itemInfo.addActionListener(new ActionListener() {
            	public void actionPerformed(ActionEvent e) {
            		if (help == null)
            			help = new HelpWindow();
                		help.setVisible(true);
            	
            }
        });
       /** Koniec MENU    */
        
        
        /**     BUTTONY */
        
        JButton btnDzielenie = new JButton("/");
        btnDzielenie.setBounds(391, 133, 60, 30);
        panel.add(btnDzielenie);
        btnDzielenie.setBackground(new Color(255, 215, 0));
        btnDzielenie.setForeground(new Color(0, 0, 0));
        btnDzielenie.setFont(new Font("Tahoma", Font.BOLD, 16));
        
        JButton btnMnozenie = new JButton("*");
        btnMnozenie.setBounds(391, 93, 60, 30);
        panel.add(btnMnozenie);
        btnMnozenie.setForeground(new Color(0, 0, 0));
        btnMnozenie.setBackground(new Color(255, 215, 0));
        btnMnozenie.setFont(new Font("Tahoma", Font.BOLD, 16));
        
        JButton btnOdejmowanie = new JButton("-");
        btnOdejmowanie.setBounds(391, 53, 60, 30);
        panel.add(btnOdejmowanie);
        btnOdejmowanie.setForeground(new Color(0, 0, 0));
        btnOdejmowanie.setBackground(new Color(255, 215, 0));
        btnOdejmowanie.setFont(new Font("Tahoma", Font.BOLD, 16));
        
        JButton btnDodawanie = new JButton("+");
        btnDodawanie.setBounds(391, 14, 60, 30);
        panel.add(btnDodawanie);
        btnDodawanie.setForeground(new Color(0, 0, 0));
        btnDodawanie.setBackground(new Color(255, 215, 0));
        btnDodawanie.setFont(new Font("Tahoma", Font.BOLD, 16));
        
        JButton btnClear = new JButton("Clear");
        btnClear.setBounds(117, 133, 90, 30);
        panel.add(btnClear);
        btnClear.setBackground(new Color(255, 215, 0));
        btnClear.setFont(new Font("Tahoma", Font.BOLD, 16));
        
        JButton btn0 = new JButton("0");
        btn0.setBounds(10, 133, 90, 30);
        panel.add(btn0);
        btn0.setBackground(new Color(255, 215, 0));
        btn0.setFont(new Font("Tahoma", Font.BOLD, 16));
        
        JButton btn3 = new JButton("3");
        btn3.setBounds(222, 93, 90, 30);
        panel.add(btn3);
        btn3.setBackground(new Color(255, 215, 0));
        btn3.setFont(new Font("Tahoma", Font.BOLD, 16));
        
        JButton btn6 = new JButton("6");
        btn6.setBounds(222, 53, 90, 30);
        panel.add(btn6);
        btn6.setBackground(new Color(255, 215, 0));
        btn6.setFont(new Font("Tahoma", Font.BOLD, 16));
        
        JButton btn9 = new JButton("9");
        btn9.setBounds(222, 14, 90, 30);
        panel.add(btn9);
        btn9.setBackground(new Color(255, 215, 0));
        btn9.setFont(new Font("Tahoma", Font.BOLD, 16));
        
        JButton btn2 = new JButton("2");
        btn2.setBounds(117, 93, 90, 30);
        panel.add(btn2);
        btn2.setBackground(new Color(255, 215, 0));
        btn2.setFont(new Font("Tahoma", Font.BOLD, 16));
        
        JButton btn5 = new JButton("5");
        btn5.setBounds(117, 53, 90, 30);
        panel.add(btn5);
        btn5.setBackground(new Color(255, 215, 0));
        btn5.setFont(new Font("Tahoma", Font.BOLD, 16));
        
        JButton btn8 = new JButton("8");
        btn8.setBounds(117, 14, 90, 30);
        panel.add(btn8);
        btn8.setBackground(new Color(255, 215, 0));
        btn8.setFont(new Font("Tahoma", Font.BOLD, 16));
        
        JButton btn1 = new JButton("1");
        btn1.setBounds(10, 93, 90, 30);
        panel.add(btn1);
        btn1.setBackground(new Color(255, 215, 0));
        btn1.setFont(new Font("Tahoma", Font.BOLD, 16));
        
        JButton btn4 = new JButton("4");
        btn4.setBounds(10, 53, 90, 30);
        panel.add(btn4);
        btn4.setBackground(new Color(255, 215, 0));
        btn4.setFont(new Font("Tahoma", Font.BOLD, 16));
        
        JButton btn7 = new JButton("7");
        btn7.setBounds(10, 14, 90, 30);
        panel.add(btn7);
        btn7.setBackground(new Color(255, 215, 0));
        btn7.setFont(new Font("Tahoma", Font.BOLD, 16));
        
        JButton btnwynik = new JButton("=");
        btnwynik.setBackground(new Color(255, 215, 0));
        btnwynik.setFont(new Font("Tahoma", Font.BOLD, 16));
        btnwynik.setBounds(222, 133, 159, 30);
        panel.add(btnwynik);
        
        JButton btnprocent = new JButton("%");
        btnprocent.setForeground(Color.BLACK);
        btnprocent.setFont(new Font("Tahoma", Font.BOLD, 16));
        btnprocent.setBackground(new Color(255, 215, 0));
        btnprocent.setBounds(321, 14, 60, 30);
        panel.add(btnprocent);
        
        JButton btnpotega = new JButton("x\u00B2");
        btnpotega.setForeground(Color.BLACK);
        btnpotega.setFont(new Font("Tahoma", Font.BOLD, 16));
        btnpotega.setBackground(new Color(255, 215, 0));
        btnpotega.setBounds(322, 53, 60, 30);
        panel.add(btnpotega);
        
        JButton btnpierwiastek = new JButton("\u221A");
        btnpierwiastek.setForeground(Color.BLACK);
        btnpierwiastek.setFont(new Font("Tahoma", Font.BOLD, 16));
        btnpierwiastek.setBackground(new Color(255, 215, 0));
        btnpierwiastek.setBounds(321, 93, 60, 30);
        panel.add(btnpierwiastek);

        
        /** DODANIE BUTTON�W */
        
        
        btn1.addActionListener(new ListenToOne());
        btn2.addActionListener(new ListenToTwo());
        btn3.addActionListener(new ListenToThree());
        btn4.addActionListener(new ListenToFour());
        btn5.addActionListener(new ListenToFive());
        btn6.addActionListener(new ListenToSix());
        btn7.addActionListener(new ListenToSeven());
        btn8.addActionListener(new ListenToEight());
        btn9.addActionListener(new ListenToNine());
        btn0.addActionListener(new ListenToZero());

        btnDodawanie.addActionListener(new ListenToAdd());
        btnOdejmowanie.addActionListener(new ListenToSubtract());
        btnMnozenie.addActionListener(new ListenToMultiply());
        btnDzielenie.addActionListener(new ListenToDivide());
        btnwynik.addActionListener(new ListenToSolve());
        btnClear.addActionListener(new ListenToClear());
        btnpierwiastek.addActionListener(new ListenToSqrt());
        btnprocent.addActionListener(new ListenToPercent());
        btnpotega.addActionListener(new ListenToDob());
 	}
	
	
	
	/* Przypisanie przycisk�w */
	
	
	/* clear */
	 class ListenToClear implements ActionListener {
	        public void actionPerformed(ActionEvent e) {
	            resultArea.setText(" ");
	            addBool = false;
	            subBool = false;
	            mulBool = false;
	            divBool = false;

	            TEMP = 0;
	            SolveTEMP = 0;
	            
	        }
	    }

	 /* liczby */
	 
	    class ListenToOne implements ActionListener {
	        public void actionPerformed(ActionEvent e) {
	            display = resultArea.getText();
	            resultArea.setText(display + "1");
	        }
	    }

	    class ListenToTwo implements ActionListener {
	        public void actionPerformed(ActionEvent e) {
	            display = resultArea.getText();
	            resultArea.setText(display + "2");
	        }
	    }

	    class ListenToThree implements ActionListener {
	        public void actionPerformed(ActionEvent e) {
	            display = resultArea.getText();
	            resultArea.setText(display + "3");
	        }
	    }

	    class ListenToFour implements ActionListener {
	        public void actionPerformed(ActionEvent e) {
	            display = resultArea.getText();
	            resultArea.setText(display + "4");
	        }
	    }

	    class ListenToFive implements ActionListener {
	        public void actionPerformed(ActionEvent e) {
	            display = resultArea.getText();
	            resultArea.setText(display + "5");
	        }
	    }

	    class ListenToSix implements ActionListener {
	        public void actionPerformed(ActionEvent e) {
	            display = resultArea.getText();
	            resultArea.setText(display + "6");
	        }
	    }

	    class ListenToSeven implements ActionListener {
	        public void actionPerformed(ActionEvent e) {
	            display = resultArea.getText();
	            resultArea.setText(display + "7");
	        }
	    }

	    class ListenToEight implements ActionListener {
	        public void actionPerformed(ActionEvent e) {
	            display = resultArea.getText();
	            resultArea.setText(display + "8");
	        }
	    }

	    class ListenToNine implements ActionListener {
	        public void actionPerformed(ActionEvent e) {
	            display = resultArea.getText();
	            resultArea.setText(display + "9");
	        }
	    }

	    class ListenToZero implements ActionListener {
	        public void actionPerformed(ActionEvent e) {
	            display = resultArea.getText();
	            resultArea.setText(display + "0");
	        }
	    }

	    /* dzia�ania matematyczne */
	    
	    class ListenToAdd implements ActionListener {
	        public void actionPerformed(ActionEvent e) {
	            TEMP = Double.parseDouble(resultArea.getText());
	            resultArea.setText(" ");
	            addBool = true;
	        }
	    }

	    class ListenToSubtract implements ActionListener {
	        public void actionPerformed(ActionEvent e) {
	            TEMP = Double.parseDouble(resultArea.getText());
	            resultArea.setText(" ");
	            subBool = true;
	        }
	    }

	    class ListenToMultiply implements ActionListener {
	        public void actionPerformed(ActionEvent e) {
	            TEMP = Double.parseDouble(resultArea.getText());
	            resultArea.setText(" ");
	            mulBool = true;
	        }
	    }

	    class ListenToDivide implements ActionListener {
	        public void actionPerformed(ActionEvent e) {
	            TEMP = Double.parseDouble(resultArea.getText());
	            resultArea.setText(" ");
	            divBool = true;
	        }
	    }
	    
	    class ListenToSqrt implements ActionListener {
	    	public void actionPerformed(ActionEvent e) {
	    		TEMP = Double.parseDouble(resultArea.getText());
	    		resultArea.setText(" ");
	    		sqrtBool = true;
	    	}
	    }
	    class ListenToPercent implements ActionListener {
	    	public void actionPerformed(ActionEvent e) {
	    		TEMP = Double.parseDouble(resultArea.getText());
	    		resultArea.setText(" ");
	    		percentBool = true;
	    	}
	    }

	    class ListenToDob implements ActionListener {
	    	public void actionPerformed(ActionEvent e) {
	    		TEMP = Double.parseDouble(resultArea.getText());
	    		resultArea.setText(" ");
	    		dobBool = true;
	    	}
	    }


	    /* rozwi�zanie */
	    
	    class ListenToSolve implements ActionListener {
	        public void actionPerformed(ActionEvent e) {
	        	SolveTEMP = Double.parseDouble(resultArea.getText( ));
	        	if (addBool == true)
	            	SolveTEMP = TEMP + SolveTEMP;
	            else if ( subBool == true)
	            	SolveTEMP = TEMP - SolveTEMP;
	            else if ( mulBool == true)
	            	SolveTEMP = TEMP * SolveTEMP;
	            else if ( divBool == true)
	            	SolveTEMP = TEMP / SolveTEMP ;
	            else if ( sqrtBool == true)
	            	SolveTEMP = (float) Math.sqrt(TEMP);
	            else if (percentBool == true)
	            	SolveTEMP = ((TEMP*100)/SolveTEMP);
	            else if (dobBool == true)
	            	SolveTEMP = (float) Math.pow(TEMP, SolveTEMP);
	            resultArea.setText(  Double.toString(SolveTEMP));

	            addBool = false;
	            subBool = false;
	            mulBool = false;
	            divBool = false;
	            sqrtBool=false;
	            percentBool=false;
	            dobBool=false;
	        }
	    }
	    /*----------------------------------------------------*/
	    
	    public double getSolveTEMP()
	    {
	    	return SolveTEMP;
	    }
	    
	    public void setSolveTEMP(double number) 
	    {
	    	resultArea.setText(  Double.toString(SolveTEMP));
	    }
	   

	/**
     * Okno - zapytanie o zamkni�cie programu.
     */

    public void windowClose() {
        int value = JOptionPane.showOptionDialog(this, "Czy napewno chcesz zako�czy� ?", "Uwaga.", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, yesNo, yesNo[0]);
        if (value == JOptionPane.YES_OPTION) {
            dispose();
            System.exit(0);
        }
    }
	

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
}
